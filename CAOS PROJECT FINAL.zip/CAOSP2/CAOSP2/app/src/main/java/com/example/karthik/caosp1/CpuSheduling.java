package com.example.karthik.caosp1;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import android.graphics.Color;

import com.numetriclabz.numandroidcharts.StackedBarChart;
//import com.github.mikephil.charting.charts.HorizontalBarChart;
//import com.github.mikephil.charting.data.BarData;
//import com.github.mikephil.charting.data.BarDataSet;
//import com.github.mikephil.charting.data.BarEntry;
//import com.github.mikephil.charting.utils.ColorTemplate;
//import com.numetriclabz.numandroidcharts.ChartData;
//import com.numetriclabz.numandroidcharts.StackAxisformatter;
//import com.numetriclabz.numandroidcharts.StackedBarChart;


/**
 * Created by karthik on 13/1/2018.
 */

public class CpuSheduling extends AppCompatActivity {

    private ImageButton goBack;
    private FloatingActionButton add,play,clear;
    //private StackedBarChart stack;
    private TextView id,txtPriority;
    private Spinner algor;
    private EditText btime,atime,Priority;
    private GridView myGrid;
    private int burstT,arrivalT;
    private TextView arr;
    private int Processcount;

    private int pid[];   // process ids
    private int ar[];     // arrival times
    private int bt[];    // burst or execution times
    private int ct[];     // completion times
    private int ta[];     // turn around times
    private int wt[];    // waiting times

    private int pidP[];   // process ids
    private int arP[];     // arrival times
    private int btP[];    // burst or execution times
    private int ctP[];     // completion times
    private int taP[];     // turn around times
    private int wtP[];    // waiting times
    private int pp[];


    private int temp = 0;
    private int temp2 = 0;
    private float avgwt=0,avgta=0;
    public double awt = 0;
    public double att = 0;
    private String al;
    ArrayList<Integer> processId= new ArrayList<Integer>();
    ArrayList<Integer> atList = new ArrayList<Integer>();
    ArrayList<Integer> btList = new ArrayList<Integer>();
    ArrayList<Integer> ctList = new ArrayList<Integer>();

    ArrayList<Integer> processId2= new ArrayList<Integer>();
    ArrayList<Integer> atList2 = new ArrayList<Integer>();
    ArrayList<Integer> btList2 = new ArrayList<Integer>();
    ArrayList<Integer> ctList2 = new ArrayList<Integer>();

    ArrayList<NPP> NonPreemptive = new ArrayList<NPP>();
    ArrayList<NPP> NonPreemptiveTemp = new ArrayList<NPP>();
    ArrayList<NPP> NonPreemptiveFinal = new ArrayList<NPP>();


    //ArrayList<Instant> FinishTime = new ArrayList<>();
     ArrayList<Integer> TurnAroundList = new ArrayList<Integer>();
     ArrayList<Integer> WaitingLst = new ArrayList<Integer>();
     ArrayList<Integer> FinishTime = new ArrayList<Integer>();

     ArrayList<Integer> TurnAroundList2 = new ArrayList<Integer>();
     ArrayList<Integer> WaitingLst2 = new ArrayList<Integer>();
     ArrayList<Integer> FinishTime2 = new ArrayList<Integer>();
     ArrayList<Integer> pPriority = new ArrayList<Integer>();


    public class NPP{
        public Integer pID;
        public Integer pAT;
        public Integer pBT;
        public Integer pPri;
    }



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cpu_scheduling);
        goBack = (ImageButton) findViewById(R.id.home);
        add = (FloatingActionButton) findViewById(R.id.fBtnAdd);
        id = (TextView) findViewById(R.id.Pid);
        algor = (Spinner) findViewById(R.id.sAlgorithm);
        play = (FloatingActionButton) findViewById(R.id.fBtnStart);
        btime = (EditText) findViewById(R.id.BurstTime);
        atime = (EditText) findViewById(R.id.ArrivalTime);
        myGrid=(GridView)findViewById(R.id.grid);
        arr = (TextView) findViewById(R.id.txt_array);
        txtPriority = (TextView) findViewById(R.id.txtPriority);
        Priority = (EditText) findViewById(R.id.etPriority);
        clear  =(FloatingActionButton) findViewById(R.id.fBtnClear);
        //stack = (StackedBarChart) findViewById(R.id.chart);

        final String[] array = new String[]{"Process ID","Arrival Time","Burst Time"};
        final String[] array2 = new String[]{"Process ID","Arrival Time","Burst Time","Priority"};
        //final String[] title = new String[]{"Process ID","Arrival Time","Burst Time"};
        // final String[] title2 = new String[]{"Process ID","Arrival Time","Burst Time","Priority"};

        // final List<String> t1 = new ArrayList<String>(Arrays.asList(title));
        //final List<String> t2 = new ArrayList<String>(Arrays.asList(title2));

        final List<String> list = new ArrayList<String>(Arrays.asList(array));
        final List<String> list2 = new ArrayList<String>(Arrays.asList(array2));

        final ArrayAdapter<String> gridViewArrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
        //final ArrayAdapter<String> gridViewArrayAdapterTitle1 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,t1);

        final ArrayAdapter<String> gridViewArrayAdapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list2);
        //final ArrayAdapter<String> gridViewArrayAdapterTitle2 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,t2);

        /// myGrid.setAdapter(gridViewArrayAdapterTitle1);
        // gridViewArrayAdapterTitle1.notifyDataSetChanged();



        txtPriority.setVisibility(View.INVISIBLE);
        Priority.setVisibility(View.INVISIBLE);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(CpuSheduling.this,
                R.array.scheduling_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.select_dialog_item);
        algor.setAdapter(adapter);

        algor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String Selection = parent.getItemAtPosition(position).toString();
                //showToast("Spinner1: position=" + position + " id=" + id);
                if(Selection.equals("Non-Preemptive Priority"))
                {
                    txtPriority.setVisibility(View.VISIBLE);
                    Priority.setVisibility(View.VISIBLE);
                    myGrid.setNumColumns(4);
                    myGrid.setAdapter(gridViewArrayAdapter2);

                    //gridViewArrayAdapter2.notifyDataSetChanged();
                    gridViewArrayAdapter2.notifyDataSetChanged();

                }
                else
                {
                    txtPriority.setVisibility(View.INVISIBLE);
                    Priority.setVisibility(View.INVISIBLE);
                    myGrid.setNumColumns(3);
                    myGrid.setAdapter(gridViewArrayAdapter);

                    //gridViewArrayAdapter.notifyDataSetChanged();
                    gridViewArrayAdapter.notifyDataSetChanged();

                }

            }

            public void onNothingSelected(AdapterView<?> parent) {
                //showToast("Spinner1: unselected");
            }
        });


        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // burstT = Integer.parseInt(btime.toString());
                // arrivalT = Integer.parseInt(atime.toString());
                //processId = Integer.parseInt(id.toString());
                boolean a = id.getText().toString().matches("[0-9]+") & atime.getText().toString().matches("[0-9]+") & btime.getText().toString().matches("[0-9]+");
                if(a )
                {
                    if(algor.getSelectedItem().toString().equals("Non-Preemptive Priority"))
                    {
                        int i = Integer.parseInt(id.getText().toString());
                        list2.add(list2.size(), id.getText().toString());
                        processId2.add(Integer.parseInt(id.getText().toString()));

                        list2.add(list2.size(), atime.getText().toString());
                        atList2.add(Integer.parseInt(atime.getText().toString()));

                        //Burst Time
                        list2.add(list2.size(), btime.getText().toString());
                        btList2.add(Integer.parseInt(btime.getText().toString()));

                        list2.add(list2.size(), Priority.getText().toString());
                        pPriority.add(Integer.parseInt(Priority.getText().toString()));

                        //myGrid.setAdapter(gridViewArrayAdapterTitle2);
                        myGrid.setAdapter(gridViewArrayAdapter2);
                        gridViewArrayAdapter2.notifyDataSetChanged();
                        id.setText(Integer.toString(++i));

                    }
                    else if(algor.getSelectedItem().toString().equals("FCFS")) {
                        int i = Integer.parseInt(id.getText().toString());

                        list.add(list.size(), id.getText().toString());
                        processId.add(Integer.parseInt(id.getText().toString()));


                        //Arrival Time
                        list.add(list.size(), atime.getText().toString());
                        atList.add(Integer.parseInt(atime.getText().toString()));

                        //Burst Time
                        list.add(list.size(), btime.getText().toString());
                        btList.add(Integer.parseInt(btime.getText().toString()));


                        // myGrid.setAdapter(gridViewArrayAdapterTitle1);
                        //  gridViewArrayAdapterTitle1.notifyDataSetChanged();
                        myGrid.setAdapter(gridViewArrayAdapter);
                        gridViewArrayAdapter.notifyDataSetChanged();
                        id.setText(Integer.toString(++i));
                    }

                }
                else if ( atime.getText().toString().matches("") |  btime.getText().toString().matches(""))
                {
                    Toast.makeText(CpuSheduling.this,"Invalid input", Toast.LENGTH_SHORT).show();
                }


            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(algor.getSelectedItem().toString().equals("FCFS"))
                {
                    fcfs();

                }
                else if(algor.getSelectedItem().toString().equals("Non-Preemptive Priority"))
                {
                    Priority();
                }


            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list.clear();
                processId.clear();
                atList.clear();
                btList.clear();
                list2.clear();
                processId2.clear();
                atList2.clear();
                btList2.clear();
                id.setText("1");
                if(algor.getSelectedItem().toString().equals("FCFS"))
                {
                    if(list.isEmpty())
                    {
                        list.add("Process ID");
                        list.add("Arrival Time");
                        list.add("Burst Time");
                        myGrid.setAdapter(gridViewArrayAdapter);

                        //gridViewArrayAdapter.notifyDataSetChanged();
                        gridViewArrayAdapter.notifyDataSetChanged();
                    }

                }
                else if(algor.getSelectedItem().toString().equals("Non-Preemptive Priority"))
                {
                    if(list2.isEmpty())
                    {
                        list.add("Process ID");
                        list.add("Arrival Time");
                        list.add("Burst Time");
                        list.add("Priority");
                        myGrid.setAdapter(gridViewArrayAdapter2);
                        gridViewArrayAdapter2.notifyDataSetChanged();
                    }
                }

            }
        });

    }


        public void fcfs()
        {
            Processcount = processId.size();

            //sort first
            for(int i = 0; i < Processcount ;i++)
            {
                for(int j = 0;j<Processcount-(i+1);j++)
                {

                    if(atList.get(j) > atList.get(j+1))
                    {
                        temp = atList.get(j);
                        atList.set(j,atList.get(j+1));
                        atList.set(j+1,temp);

                        temp = btList.get(j);
                        btList.set(j,btList.get(j+1));
                        btList.set(j+1,temp);

                        temp = processId.get(j);
                        processId.set(j,processId.get(j+1));
                        processId.set(j+1,temp);
                    }
                }

            }

            Integer[] pid = processId.toArray(new Integer[processId.size()]);
            Integer[] at = atList.toArray(new Integer[atList.size()]);
            Integer[] bt = btList.toArray(new Integer[btList.size()]);
            Integer[] ct = new Integer[99];//Completion Time
            Integer[] tt = new Integer[99];//Turnaround Time
            Integer[] wt = new Integer[99];//Waiting Time
            int twt = 0;
            int ttt = 0;




            for(int o = 0; o< processId.size(); o++)
            {
                if (ct[0] == null) {
                    ct[o] = (at[o] + bt[o]);

                }
                else
                {
                    if(ct[o-1]  <= at[o]) {
                        ct[o] = ct[o - 1] + bt[o];
                    }
                    else
                        ct[o] = at[o] + bt[o];
                }

            }

            for (int u = 0; u < processId.size(); u++)
            {
                tt[u] = ct[u] - at[u];
            }

            for (int v = 0; v < processId.size(); v++)
            {
                wt[v] = tt[v] - bt[v];
            }

            for(int h = 0; h < Processcount; h++)
            {
                twt = twt + wt[h];
            }

            for (int q = 0; q < Processcount; q++)
            {
                ttt = ttt + tt[q];
            }

            awt = (double) twt/Processcount;
            att = (double) ttt/Processcount;

           // ArrayList<ChartData> data = new ArrayList<ChartData>();

           // for(int i = 0; i< Processcount; i++)
           // {
          //      data.add(new ChartData("Gantt Chart",bt[i]));
          //  }
          //  stack.setPercentageStacked(false);
          //  stack.setHorizontalStckedBar(true);
           // stack.setData(data);



            AlertDialog.Builder ab1 = new AlertDialog.Builder(CpuSheduling.this);

            ab1.setMessage("The Average Waiting Time is " + Double.toString(awt)+" and the Average Turnaround Time is " + Double.toString(att)+ "");
            ab1.setCancelable(true);

            ab1.setPositiveButton(
                    "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert11 = ab1.create();
            alert11.show();


        }




    public void Priority()
    {
        NonPreemptiveTemp.clear();
        NonPreemptive.clear();

        for(int i = 0; i < processId.size();i++)
        {
            NPP nppClass = new NPP();
            nppClass.pAT = atList2.get(i);
            nppClass.pBT = btList2.get(i);
            nppClass.pID = processId2.get(i);
            nppClass.pPri = pPriority.get(i);
            NonPreemptive.add(nppClass);
        }



        //NPP nppItem = NonPreemptive.get(x);


        Collections.sort(NonPreemptive, new Comparator<NPP>() {
            @Override
            public int compare(NPP npp, NPP t1) {
                return npp.pAT.compareTo(t1.pAT);
            }
        });

        Integer currentHighPR = 10000; //set high value
        Integer currentHighBT = 10000; //set high value
        Integer initialTime = 10000;
        Integer initialBurstTime = 0;
        Integer currentP2 = 0;
        //set high value
        for(int p=0;p<NonPreemptive.size();p++)
        {
            Integer currentP = p;

            if(NonPreemptiveTemp.size() == 0) {


                for (int k = p; k < NonPreemptive.size(); k++) {
                    if (NonPreemptive.get(currentP).pAT > NonPreemptive.get(k).pAT) {
                        currentP = k;
                    } else if (NonPreemptive.get(currentP).pAT == NonPreemptive.get(k).pAT) {
                        if (NonPreemptive.get(currentP).pPri > NonPreemptive.get(k).pPri) {
                            currentP = k;
                        } else if (NonPreemptive.get(currentP).pPri == NonPreemptive.get(k).pPri) {
                            if (NonPreemptive.get(currentP).pBT > NonPreemptive.get(k).pBT) {
                                currentP = k;
                            } else {
                                currentP = k;
                            }
                        }
                    }


                }//end of k
                Collections.swap(NonPreemptive,currentP,p);
            }
            else
            {
                currentP = 0;
                for (int k = 0; k < NonPreemptiveTemp.size(); k++) {

                    if (NonPreemptiveTemp.get(currentP).pPri > NonPreemptiveTemp.get(k).pPri) {
                        currentP = k;
                    } else if (NonPreemptiveTemp.get(currentP).pPri == NonPreemptiveTemp.get(k).pPri) {
                        if (NonPreemptiveTemp.get(currentP).pBT > NonPreemptiveTemp.get(k).pBT) {
                            currentP = k;
                        } else {
                            currentP = k;
                        }
                    }



                }//end of k
                Integer getProcessID = NonPreemptiveTemp.get(currentP).pID;
                for(int j=0;j<NonPreemptive.size();j++)
                {
                    if(NonPreemptive.get(j).pID.equals(getProcessID))
                    {
                        currentP2 = j;
                    }
                }

                Collections.swap(NonPreemptive, currentP2, p);
            }




            // Collections.swap(NonPreemptive,currentP,p);
            if(initialTime == 10000)
            {

                initialTime = NonPreemptive.get(p).pAT;
                initialBurstTime = NonPreemptive.get(p).pBT;
                initialTime = initialTime + initialBurstTime;
            }
            else
            {
                initialBurstTime = NonPreemptive.get(p).pBT;
                initialTime = initialTime + initialBurstTime;
            }

            NonPreemptiveTemp.clear();
            for(int h=p;h<NonPreemptive.size();h++)
            {
                if(h+1 == NonPreemptive.size())
                {

                }
                else
                {
                    Integer j = h+1;
                    NPP nppClass = new NPP();
                    nppClass.pAT = NonPreemptive.get(j).pAT;
                    nppClass.pBT = NonPreemptive.get(j).pBT;
                    nppClass.pID = NonPreemptive.get(j).pID;
                    nppClass.pPri = NonPreemptive.get(j).pPri;
                    NonPreemptiveTemp.add(nppClass);
                }

            }

        }
        Processcount = processId2.size();

        Integer[] at = atList2.toArray(new Integer[atList2.size()]);
        Integer[] bt = btList2.toArray(new Integer[btList2.size()]);
        Integer[] ct = new Integer[99];
        Integer[] tt = new Integer[99];
        Integer[] wt = new Integer[99];
        int twt = 0;
        int ttt = 0;
        double awt = 0.0;
        double att = 0;


        //completion time
        for(int o = 0; o< processId2.size(); o++)
        {
            if (ct[0] == null) {
                ct[o] = (at[o] + bt[o]);

            }
            else
            {

                ct[o] = ct[o-1] + bt[o];
            }

        }

        //turnaround time
        for (int u = 0; u < processId2.size(); u++)
        {
            tt[u] = ct[u] - at[u];
        }

        //waiting time
        for (int v = 0; v < processId2.size(); v++)
        {
            wt[v] = tt[v] - bt[v];
        }

        //total waiting time
        for(int h = 0; h < Processcount; h++)
        {
            twt = twt + wt[h];
        }

        //total turnaround time
        for (int q = 0; q < Processcount; q++)
        {
            ttt = ttt + tt[q];
        }

        awt = (double) twt/Processcount;
        att = (double) ttt/Processcount;

        AlertDialog.Builder ab1 = new AlertDialog.Builder(CpuSheduling.this);

        ab1.setMessage("The Average Waiting Time is " + Double.toString(awt)+" and the Average Turnaround Time is " + Double.toString(att)+ "");
        ab1.setCancelable(true);

        ab1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert11 = ab1.create();
        alert11.show();

    }

}
