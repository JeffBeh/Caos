package com.example.karthik.caosp1;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * Created by karthik on 15/1/2018.
 */

public class MainMemory extends AppCompatActivity {
    private ImageButton h, add;
    private GridView myGrid;
    private Spinner selection;
    private LinearLayout FirstTab,SecondTab;
    private ArrayAdapter<String> listAdapter ;
    private View FirstTabs;
    private ListView SecondTabs;
    Integer[] ListElements = new Integer[] {
    };
    Integer[] ProcessList = new Integer[] {
    };

    Integer[] ProcessContent = new Integer[]{

    };
    Integer[] MemoryContent = new Integer[]{

    };
    Integer[] rvmContent = new Integer[]{

    };
    Integer[] tempContent = new Integer[]
            {

            };
    Integer[] tempFilters = new Integer[]{};
    public  Integer count;

    public List<Integer> MemoryList, GVList, rmvNum, processResult, memoryResult, tempMemory,tempFilter;
    public ArrayList<Integer>   pList, mList = new ArrayList<>();
    private ArrayAdapter < Integer > arrayAdapter, GVAdapter;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_memory);
        h = (ImageButton) findViewById(R.id.home);
        add = (ImageButton) findViewById(R.id.iBadd);
        myGrid = (GridView) findViewById(R.id.Grid);
        selection = (Spinner) findViewById(R.id.spinner);




        FirstTabs = (View) findViewById(R.id.rightSide);
        SecondTabs = (ListView) FirstTabs.findViewById(R.id.memBlock);

       ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
       ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        // Add Fragments to adapter one by one
        adapter.addFragment(new Fragment1(), "Create Memory Block");
        adapter.addFragment(new Fragment2(), "Input Processes");
        viewPager.setAdapter(adapter);
//
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });

       MemoryList = new ArrayList < Integer >(Arrays.asList(ListElements));
        processResult = new ArrayList<Integer>(Arrays.asList(ProcessContent));
        memoryResult = new ArrayList<Integer>(Arrays.asList(MemoryContent));
        rmvNum = new ArrayList<Integer>(Arrays.asList(rvmContent));
        tempMemory = new ArrayList<Integer>(Arrays.asList(tempContent));
        tempFilter = new ArrayList<Integer>(Arrays.asList(tempFilters));

        arrayAdapter = new ArrayAdapter < Integer >(MainMemory.this, R.layout.liststyle, MemoryList);



        SecondTabs.setAdapter(arrayAdapter);

        GVList  = new ArrayList<Integer>(Arrays.asList(ProcessList));

        GVAdapter = new ArrayAdapter<Integer>(this,R.layout.liststyle,GVList );

        myGrid.setAdapter(GVAdapter);




    }


    public void addBlock(Integer memory)
    {
       // listAdapter.add( "Test123" );
      //  SecondTabs.setAdapter(listAdapter);


        //adapter.notifyDataSetChanged();

        MemoryList.add(memory);
        mList.add(memory);
        arrayAdapter.notifyDataSetChanged();
    }


    public void addProcess(Integer process)
    {
        //GVList.add(process);
        Integer p = process;
        GVList.add(p);
        GVAdapter.notifyDataSetChanged();
        arrayAdapter.notifyDataSetChanged();
    }

    public void compute()
    {

        //start of best fit
        if(selection.getSelectedItem().toString().equals("Best Fit")) {


            for (int i = 0; i < GVList.size(); i++)
            {

                int currmin = 0;
                int leastmin = 10000;
                int currMinCount = 0;
                boolean flag1 = false;


                int process = GVList.get(i);
                for (int z = 0; z < MemoryList.size(); z++) {
                    boolean flag = false;

                    if (rmvNum.isEmpty()) {
                        int memory = MemoryList.get(z);

                        if (process <= memory) {
                            flag1 = true;
                            currmin = memory - process;
                            if (currmin < leastmin) {
                                leastmin = currmin;
                                currMinCount = z;
                            }
                        }


                    } else {
                        for (int x = 0; x < rmvNum.size(); x++) {
                            if (rmvNum.get(x) == z) {
                                flag = true;
                            }
                        }

                        if (flag == false) {
                            int memory = MemoryList.get(z);

                            if (process <= memory) {
                                flag1 = true;
                                currmin = memory - process;
                                if (currmin < leastmin) {
                                    leastmin = currmin;
                                    currMinCount = z;
                                }
                            }
                        }

                    } //end of else
                } //end of for loop
                rmvNum.add(currMinCount);
                processResult.add(process);
                if(flag1 == true)
                {
                    memoryResult.add(MemoryList.get(currMinCount));
                }
                else
                {
                    memoryResult.add(0);
                }



            } //end of best fit

            Integer internalFrag = 0;
            Integer externalFrag = 0;
            Boolean externalFlag = false;
            //internalFrag
            for(int p=0;p<processResult.size();p++)
            {
                if(memoryResult.get(p) == 0)
                {
                    externalFlag = true;
                }
                else
                {
                    internalFrag = internalFrag + (memoryResult.get(p) - processResult.get(p));
                }

            }

            //externalFrag
            tempFilter.clear();

            if(externalFlag == true)
            {
                for(int j=0;j<MemoryList.size();j++)
                {
                    tempFilter.add(MemoryList.get(j));
                }


                for(int l=0;l<memoryResult.size();l++)
                {
                    for(int k=0;k<MemoryList.size();k++)
                    {
                        if(memoryResult.get(l) == MemoryList.get(k))
                        {
                            tempFilter.remove(k);
                        }
                    }
                }


                for(int p=0;p<tempFilter.size();p++)
                {
                    externalFrag = externalFrag + tempFilter.get(p);
                }
            }
            else
            {
                externalFrag = 0;
            }

            AlertDialog.Builder ab1 = new AlertDialog.Builder(MainMemory.this);

            ab1.setMessage("The Internal Fragmentation is " + Integer.toString(internalFrag)+" and the External Fragmentation is " + Integer.toString(externalFrag)+ "");
            ab1.setCancelable(true);

            ab1.setPositiveButton(
                    "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert11 = ab1.create();
            alert11.show();


        } //end of best fit

        else if(selection.getSelectedItem().toString().equals("First Fit"))
        {
            boolean externalFlags = false;
            //tempMemory = MemoryList;
            tempMemory.clear();
            for(int k=0;k<MemoryList.size();k++)
            {
                tempMemory.add(k,MemoryList.get(k));
            }



            for (int i = 0; i < GVList.size(); i++) {

                int currmin = 0;
                int leastmin = 10000;
                int currMinCount = 0;
                boolean flag1 = false;

                int process = GVList.get(i);
                for (int z = 0; z < MemoryList.size(); z++) {
                    int memory = tempMemory.get(z);

                    if (process <= memory) {
                        currmin = memory - process;
                        flag1 = true;
                        tempMemory.set(z,currmin);
                        currMinCount = z;
                        z = MemoryList.size();

                    }



                }
                //rmvNum.add(currMinCount);
                processResult.add(process);
                if(flag1 == true)
                {
                    memoryResult.add(MemoryList.get(currMinCount));
                }
                else
                {
                    externalFlags   = true;
                   memoryResult.add(0);
                }


            }


            //InternalFrag
            Integer internalFrag = 0;
            Integer externalFrag = 0;

            Integer number = 0;

            for(int p=0;p<MemoryList.size();p++)
            {
                boolean add = false;

                    for(int y=0;y<tempMemory.size();y++)
                    {
                        if(tempMemory.get(p) == MemoryList.get(y))
                        {
                            number = p;
                            add = true;
                        }
                    }


                if(add == true)
                {
                    rmvNum.add(tempMemory.get(number));
                    tempMemory.set(number,0);
                }

            }

            for(int k=0;k<tempMemory.size();k++)
            {
                internalFrag += tempMemory.get(k);
            }

            //ExternalFrag

            tempFilter.clear();

            if(externalFlags == true)
            {
               for(int h=0;h<rmvNum.size();h++)
               {
                   externalFrag += rmvNum.get(h);
               }
            }
            else
            {
                externalFrag = 0;
            }

            AlertDialog.Builder ab1 = new AlertDialog.Builder(MainMemory.this);

            ab1.setMessage("The Internal Fragmentation is " + Integer.toString(internalFrag)+" and the External Fragmentation is " + Integer.toString(externalFrag)+ "");
            ab1.setCancelable(true);

            ab1.setPositiveButton(
                    "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alert11 = ab1.create();
            alert11.show();


        }//end of first fit

    }

    public void clearValues()
    {
        GVList.clear();
        MemoryList.clear();
        processResult.clear();
        memoryResult.clear();
        tempMemory.clear();
        tempFilter.clear();
        rmvNum.clear();

        GVAdapter.notifyDataSetChanged();
        arrayAdapter.notifyDataSetChanged();


    }


    // Adapter for the viewpager using FragmentPagerAdapter
    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

}
