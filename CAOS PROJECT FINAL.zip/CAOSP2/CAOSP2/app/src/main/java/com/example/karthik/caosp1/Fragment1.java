package com.example.karthik.caosp1;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by karthik on 20/1/2018.
 */




public class Fragment1 extends Fragment {
    //private ImageButton add;
    private View v, s;
    private String i;
    private EditText EditMem;
    private ArrayAdapter<String> listAdapter ;
    MainMemory mr;
    private FloatingActionButton add;
    public int[] mb;

    public final ArrayList<Integer> MEMORYBLOCK = new ArrayList<Integer>();

    public Fragment1() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v=  inflater.inflate(R.layout.memory_block, container, false);

        add = (FloatingActionButton) v.findViewById(R.id.iBadd);
        EditMem = (EditText) v.findViewById(R.id.etMemoryblock);



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String memoryBlock = EditMem.getText().toString();

             //Toast.makeText(getContext(),"Test123", Toast.LENGTH_SHORT).show();

                if(memoryBlock.matches(""))
                {
                    Toast.makeText(getContext(),"Invalid input", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    ((MainMemory)getActivity()).addBlock(Integer.parseInt(memoryBlock));
                     //MEMORYBLOCK.add(Integer.parseInt(memoryBlock));
                }


            }
        });
        return v;
    }

    public String getValue()
    {
        return  i;

    }

}
