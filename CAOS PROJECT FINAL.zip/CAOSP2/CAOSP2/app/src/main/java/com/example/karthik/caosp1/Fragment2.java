package com.example.karthik.caosp1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by karthik on 20/1/2018.
 */

public class Fragment2 extends Fragment {
    private EditText edt3;
    private TextView pid;
    private EditText size;
    private FloatingActionButton add;
    private View view;
    private String Pid,Psize;
    private Button compute;
    private int ProcessID = 1;
    private FloatingActionButton clean;

    public Fragment2() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.process_memory, container, false);
        //edt3 = (EditText) view.findViewById(R.id.editText3);
        pid = (TextView) view.findViewById(R.id.txtProcessID);
        size = (EditText) view.findViewById(R.id.etSize);
        add = (FloatingActionButton) view.findViewById(R.id.fbAdd);
        compute = (Button) view.findViewById(R.id.btnCompute);
        clean = (FloatingActionButton) view.findViewById(R.id.fBtnClean);


       add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String process = size.getText().toString();

                if(process.matches(""))
                {
                    Toast.makeText(getContext(),"Invalid input", Toast.LENGTH_SHORT).show();

                }
                else
                {

                    ((MainMemory)getActivity()).addProcess(Integer.parseInt(process));
                    // MEMORYBLOCK.add(Integer.parseInt(memoryBlock));
                    ProcessID = ProcessID + 1;
                   pid.setText(Integer.toString(ProcessID));
                }



           }
        });

        compute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    ((MainMemory)getActivity()).compute();
                    //startActivity(new Intent(Fragment2.this,Pop.class));
            }
        });

        clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ((MainMemory)getActivity()).clearValues();
                pid.setText("1");

            }
        });

        return view;
    }
}
